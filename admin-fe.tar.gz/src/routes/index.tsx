import { createFileRoute } from '@tanstack/react-router'



export const Route = createFileRoute('/')({
    component: () => (
      <div className="w-full h-screen bg-cyan-300">sdd</div>
    ),
  })